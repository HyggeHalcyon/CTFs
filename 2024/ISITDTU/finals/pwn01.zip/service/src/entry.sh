#!/bin/bash

/app/src/source